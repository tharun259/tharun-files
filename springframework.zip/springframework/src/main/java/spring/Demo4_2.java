package spring;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import java.util.*;

public class Demo4_2 {
public static void main(String[] args) {
	ApplicationContext context=new AnnotationConfigApplicationContext(JavaContainer.class);
	DriverManagerDataSource dr=context.getBean(DriverManagerDataSource.class);
	JdbcTemplate jd=context.getBean(JdbcTemplate.class);
	jd.setDataSource(dr);
	
	String query1="insert into empmaster values(?,?,?,?)";
	int output=jd.update(query1,"E101","1111-02-03","Captain","America");
	System.out.print(output);
	
//	String query2="select * from empmaster";
//	List<Map<String,Object>> l1=jd.queryForList(query2);
//	l1.forEach((l2)->{
//		System.out.println()
//	})
}
}
