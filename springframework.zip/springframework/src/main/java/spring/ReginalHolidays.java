package spring;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
@Component
public class ReginalHolidays {

public void display() {
	System.out.println("Your Reginal Holiday");
}
}
