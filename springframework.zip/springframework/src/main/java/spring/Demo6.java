package spring;
import java.beans.Expression;
import java.util.*;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
public class Demo6 {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Equation");
	String exp=sc.nextLine();
	ExpressionParser exparser=new SpelExpressionParser();
	Double result=exparser.parseExpression(exp).getValue(Double.class);
	System.out.println(exp+" = "+result);
}
}	
 		    