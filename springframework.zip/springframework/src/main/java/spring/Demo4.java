package spring;
import spring.JavaContainer; 
import p2.Arithmetic1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
@Configuration
@ComponentScan(basePackages = {"spring", "p2"})
@EnableAspectJAutoProxy(proxyTargetClass = true)
public class Demo4 {
	@Autowired
@Qualifier("f8")
	private Arithmetic1 dr;
public static void main(String[] args) {
	try {
		Demo4 ac= new AnnotationConfigApplicationContext(Demo4.class).getBean(Demo4.class);
		//Arithmetic ar=(Arithmetic)ac.getBean("f3");
		System.out.println(ac.dr.compute(10, 1));
	}catch(Exception e) {
		System.out.println(e.getMessage());
	}
	
}
}
