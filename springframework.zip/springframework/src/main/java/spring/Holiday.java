package spring;

public class Holiday {
	public String holidayname;
	public String holidayDate;
	public String getHolidayname() {
		return holidayname;
	}
	public void setHolidayname(String holidayname) {
		this.holidayname = holidayname;
	}
	public String getHolidayDate() {
		return holidayDate;
	}
	public void setHolidayDate(String holidayDate) {
		this.holidayDate = holidayDate;
	}
	public Holiday() {
		
	}
	public void display() {
	System.out.println(getHolidayname()+" "+getHolidayDate());
	}
}
