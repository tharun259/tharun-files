package spring;
															
import org.springframework.context.annotation.Bean; 
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.core.JdbcTemplate;
import p2.*;
@Configuration
@EnableAspectJAutoProxy
@ComponentScan("spring.*")
public class JavaContainer {
@Bean
@Lazy
@Scope("singleton")
public Holiday f1() {
	Holiday ob=new Holiday();
	ob.setHolidayDate("12 Jan");
	ob.setHolidayname("Pongal");
	return ob;
}
@Bean
public Holiday f2() {
	Holiday ob=new Holiday();
	ob.setHolidayDate("2 Oct");
	ob.setHolidayname("Gandhi Jayanthi");
	return ob;
}
@Bean
public Calculator f3() {
	return new Calculator();
}
@Bean
public ValidateCalculator f4() {
	return new ValidateCalculator();
}
@Bean
public Arithmetic1 f5() {
	return new Addition();
}

@Bean
public Arithmetic1 f6() {
	return new Subtraction();
}
@Bean
public Arithmetic1 f7() {
	return new Multiplication();
}
@Bean
public Arithmetic1 f8() {
	return new Division();
}

@Bean
public DriverManagerDataSource f9() {
	DriverManagerDataSource ob=new DriverManagerDataSource();
	ob.setDriverClassName("com.mysql.cj.jdbc.Driver");
	ob.setUrl("jdbc:mysql://localhost:3306/employee");
	ob.setUsername("root");
	ob.setPassword("root@39");
	return ob;
	
}
@Bean
public JdbcTemplate f10() {
	JdbcTemplate jb=new JdbcTemplate(f9());
	return jb;
}
}
