package spring;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class Demo1 {
public static void main(String[] args){
	Holiday oh;

	ApplicationContext appcontext=new ClassPathXmlApplicationContext("container.xml");
	oh=(Holiday)appcontext.getBean("holiday");
	oh.display();


	
}
}
