package spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
@Configuration
@ComponentScan("spring")
public class Demo5 {
	@Autowired
	ReginalHolidays ob;
	public static void main(String[] args) {
		try {
		Demo5 d=new Demo5();
		d=new AnnotationConfigApplicationContext(Demo5.class).getBean(Demo5.class);
		d.ob.display();
		
		}catch(Exception e) {}
	}

}
