package p2;

public interface Arithmetic1 {
public double compute(double num1,double num2);
}
