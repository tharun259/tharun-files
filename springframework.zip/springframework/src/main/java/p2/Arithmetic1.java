package p2;

import org.springframework.stereotype.Component;

@Component
public interface Arithmetic1 {
public double compute(double num1,double num2);
}
