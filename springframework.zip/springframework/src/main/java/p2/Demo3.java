package p2;
import spring.JavaContainer;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
public class Demo3 {
public static void main(String[] args) {
	try {
		ApplicationContext ac= new AnnotationConfigApplicationContext(JavaContainer.class);
		Arithmetic ar=(Arithmetic)ac.getBean("f3");
		System.out.println(ar.div(10, 0));
	}catch(Exception e) {
		System.out.println(e.getMessage());
	}
	
}
}
