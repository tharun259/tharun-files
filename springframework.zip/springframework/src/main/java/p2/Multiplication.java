package p2;

public class Multiplication implements Arithmetic1 {
	public double compute(double num1,double num2) {
		return num1*num2;
	}
}
