package p2;

public class Subtraction implements Arithmetic1 {
	public double compute(double num1,double num2) {
		return num1-num2;
	}
}
