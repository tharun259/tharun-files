package p2;

import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;



public class Division implements Arithmetic1 {
public double compute(double num1,double num2) {
	return num1/num2;
}
}
