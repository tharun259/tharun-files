package p2;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Aspect
@Order(0)
@Component
public class ValidateCalculator {
	@Before("execution(* *.* (double , double))")
	public void checkZero(JoinPoint jp) throws IllegalArgumentException{
		if((Double)jp.getArgs()[1]==0) {
			throw new IllegalArgumentException("Second argument cannot be a zero"+jp.getSignature());
		}
	}
@Before("execution(* *.*(double , double))")
public void checkNegative(JoinPoint jp) throws IllegalArgumentException{
	for(Object x: jp.getArgs()) {
		 if((Double)x<0) {
			 throw new IllegalArgumentException("Negative numbers not supported"); 
		 }
	}
}
@AfterReturning(pointcut="execution(* *.*(double , double))",returning="result")
public void checkReturn(JoinPoint jp,Object result) throws IllegalArgumentException {
	if((Double)result>200000) {
		throw new IllegalArgumentException("Returning value is more than 200000. We cannot prcess your transaction");
	}
}

}
