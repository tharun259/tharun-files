package p1;

import java.text.SimpleDateFormat;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class Demo10 {
	public static void main(String[] args) {
		System.out.println("Program begins");
		Configuration conf = new Configuration();
		conf.configure("hibernate.cfg.xml");
		Session session = conf.buildSessionFactory().openSession();
		Transaction transaction= session.beginTransaction(); ;
		try {
			
			SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd");
			System.out.println("Enter id");
			String s1 = Read.sc.nextLine();

            int rows = session.createNativeQuery(
                    "DELETE FROM empmaster WHERE empid = :n1")
                .setParameter("n1", s1) // or .setParameter("n1", id)
                .executeUpdate();

            if (rows == 0) {
                System.out.println("No employee found for id: " + s1);
            } else {
                System.out.println("Successfully deleted " + rows + " record(s) for id: " + s1);
            }


            transaction.commit();
			
		} catch (Exception e) {

            if (transaction != null) transaction.rollback();
            e.printStackTrace();

		}
		finally {

            session.close();
            System.out.println("Program ends");

		}
	}
}
