package p1;




import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.text.SimpleDateFormat;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;

public class Demo1 {
	
	
	public static void main(String[] args) {
		try {
//			System.out.println("Enter the Id ");
//			String empID=Read.sc.nextLine();
//
//			System.out.println("Enter the fname ");
//			String empfname=Read.sc.nextLine();
//			
//			System.out.println("Enter the lname ");
//			String emplname=Read.sc.nextLine();
//			
//			System.out.println("Enter the dob");
//			String dob=Read.sc.nextLine();
//			
			
			System.out.println("Program Begins");
			Configuration confg=new Configuration();
			
			confg.configure("hibernate.cfg.xml");
			Session session =confg.buildSessionFactory().openSession();
			Transaction trans=session.beginTransaction();
			SimpleDateFormat date=new SimpleDateFormat("yyyy-mm-dd");
			
			
			EmployeeEntity emp=session.get(EmployeeEntity.class,"122");
			System.out.println(emp);
			emp=new EmployeeEntity("E102","Caption","America",date.parse("1238-2-12"));
			EmployeeEntity emp2=session.get(EmployeeEntity.class,"E102");
			System.out.println(emp2);
			trans.commit();
			session.close();
			System.out.println("Program Ends");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
	}
}
