package p1;
 
import java.text.SimpleDateFormat;
import java.util.List;
 
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
 
public class Demo9 {
	public static void main(String[] args) {
		
		try {
			System.out.println("Program begins");
			Configuration conf = new Configuration();
			conf.configure("hibernate.cfg.xml");
			Session session = conf.buildSessionFactory().openSession();
			Transaction transaction = session.beginTransaction();
			SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd");
			System.out.println("Enter id");
			String s1 = Read.sc.nextLine();
			Query q1 = session.createNativeQuery("Select * from empmaster where empid =:n1",EmployeeEntity.class);
			q1.setParameter("n1",s1);
			EmployeeEntity emp = (EmployeeEntity)q1.getSingleResult();
			System.out.println(emp);
			
			
			transaction.commit();
			session.close();
			System.out.println("Program ends");
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}