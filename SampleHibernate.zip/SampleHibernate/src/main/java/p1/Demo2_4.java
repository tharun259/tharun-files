package p1;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Demo2_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Program begins");
		Configuration conf = new Configuration();
		conf.configure("hibernate.cfg.xml");
		Session session = null;
		Transaction transaction=null;
		
		try {
			session = conf.buildSessionFactory().openSession();
			transaction= session.beginTransaction(); 

			String ch="0";
			do {
				System.out.println("Enter the qid and q name");
				QualificationEntity qual=new QualificationEntity(Read.sc.nextLine(),Read.sc.nextLine());
				session.persist(qual);
				//transaction.commit();
				System.out.println("Enter 1 to continous");
				ch=Read.sc.nextLine();
				
			}while(ch.equals("1"));
			transaction.commit();
			session.close();
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
