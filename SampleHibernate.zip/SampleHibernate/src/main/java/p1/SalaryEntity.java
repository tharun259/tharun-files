package p1;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="empsalary")
public class SalaryEntity {
	@Id
	private String tid;
	
	@Column
	private Date dos;
	private int salary;
	
	//many to one 
	@ManyToOne //for implementing join 
	@JoinColumn(name="empid")
	private EmployeeEntity emp;
	
	
	

	public SalaryEntity() {
		
	}

	public SalaryEntity(String tid, Date dos, int salary, EmployeeEntity emp) {
		super();
		this.tid = tid;
		this.dos = dos;
		this.salary = salary;
		this.emp = emp;
	}

	public String getTid() {
		return tid;
	}

	public void setTid(String tid) {
		this.tid = tid;
	}

	public Date getDos() {
		return dos;
	}

	public void setDos(Date dos) {
		this.dos = dos;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public EmployeeEntity getEmp() {
		return emp;
	}

	public void setEmp(EmployeeEntity emp) {
		this.emp = emp;
	}

	@Override
	public String toString() {
		return "SalaryEntity [tid=" + tid + ", dos=" + dos + ", salary=" + salary + ", emp=" + emp + "]";
	}
	
	
	
	
	
}
