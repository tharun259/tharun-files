
package p1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class Demo2_2 {
    public static void main(String[] args) {
        System.out.println("Program Starts");

        Configuration confg = new Configuration();
        confg.configure("hibernate.cfg.xml");
        SessionFactory factory = confg.buildSessionFactory();

        Session session = null;
        Transaction tx = null;

        try {
            session = factory.openSession();
            tx = session.beginTransaction();

            System.out.println("Enter the emp id ");
            String s1 = Read.sc.nextLine();  // ensure Read.sc is a valid Scanner

            // Preferred HQL using mapped association (SalaryEntity has ManyToOne 'emp')
            String hql =
                "select e.empid, e.empfname, s.tid, s.salary " +
                "from SalaryEntity s " +
                "join s.emp e " +
                "where e.empid = :empid";

            Query<Object[]> q1 = session.createQuery(hql, Object[].class);
            q1.setParameter("empid", s1); 

            java.util.List<Object[]> rows = q1.getResultList();
            for (Object[] row : rows) {

                System.out.println(
                    "empid=" + (String) row[0] +
                    ", empfname=" + (String) row[1] +
                    ", tid=" + (String) row[2] +
                    ", salary=" +  (Integer) row[3]
                );
            }

            tx.commit();
        } catch (Exception ex) {
            if (tx != null) tx.rollback();
            ex.printStackTrace();
        } finally {
            if (session != null) session.close();
            factory.close();
        }

        System.out.println("Program Ends");
    }
}
