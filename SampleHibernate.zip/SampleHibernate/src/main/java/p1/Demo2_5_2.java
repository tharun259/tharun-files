package p1;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Demo2_5_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Program begins");
		Configuration conf = new Configuration();
		conf.configure("hibernate.cfg.xml");
		Session session = null;
		Transaction transaction=null;
		try {
			
			session = conf.buildSessionFactory().openSession();
			transaction= session.beginTransaction(); 
			
			//String empId=Read.sc.nextLine();

		    //EmployeeEntity emp = session.get(EmployeeEntity.class, "1010");
            
		    Query q1=session.createNamedQuery("n2");
		    
		    List<EmployeeEntity> list=q1.getResultList();
		    
		    list.forEach(
		    		(ob)->{
		    			StringBuilder sb=new StringBuilder();
		    			
		    			for (QualificationEntity x: ob.getQual()) {
							sb.append(x.getQname());
						}
		    			System.out.println(ob.getEmpid() + " " + ob.getEmpfname()+" "+sb.toString()+" "+ob.getQual());
		    		}
		    		
		    		);
		    
			session.persist(q1);
			transaction.commit();
			session.close();
			
			System.out.println("Program ends");
	
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}	
	}
	public static void f1(EmployeeEntity ob) {
		System.out.println(ob.getEmpid() + " " + ob.getEmpfname());
	}
}


// write a program to empid , empname, qualification