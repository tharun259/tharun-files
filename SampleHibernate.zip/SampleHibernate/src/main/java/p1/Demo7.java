package p1;
 
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
 
public class Demo7 {
	
	public static void main(String[] args) {
		try {
			System.out.println("Program Begins");
			Configuration conf = new Configuration();
			conf.configure("hibernate.cfg.xml");
			Session session = conf.buildSessionFactory().openSession();
			Transaction trans = session.beginTransaction();
			SimpleDateFormat date = new SimpleDateFormat("yyyy-mm-dd");
			
			System.out.println("Enter name to display");
			String s1 = Read.sc.nextLine();
			Query q1 = session.createQuery("from EmployeeEntity where empid =: name ");
			q1.setParameter("name", s1);
			//selection and projection  
			List<EmployeeEntity> emp = q1.getResultList();
			
			
			emp.forEach(System.out::println);			
			trans.commit();
			session.close();
			System.out.println("Program Ends");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public static void f1(Object ob[]) {
		
		
		for(Object x:ob) {
			System.out.println(x);
		}
		
	}
 
}
 