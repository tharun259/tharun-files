package p1;
 
import java.text.SimpleDateFormat;
import java.util.List;
 
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
 
 
public class Demo4 {
	
	public static void main(String[] args) {
		try {
			System.out.println("Program Begins");
			Configuration conf = new Configuration();
			conf.configure("hibernate.cfg.xml");
			Session session = conf.buildSessionFactory().openSession();
			Transaction trans = session.beginTransaction();
			SimpleDateFormat date = new SimpleDateFormat("yyyy-mm-dd");
			
			Query q1 = session.createQuery("from EmployeeEntity");
			List<EmployeeEntity> emp = q1.getResultList();
			//emp.forEach(System.out::println);	
			emp.forEach(Demo4::f1);
			
			trans.commit();
			session.close();
			System.out.println("Program Ends");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public static void f1(EmployeeEntity ob) {
		System.out.println(ob.getEmpid() + " " + ob.getEmpfname());
	}
 
}
 