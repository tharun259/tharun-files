package p1;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Demo2_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Program begins");
		Configuration conf = new Configuration();
		conf.configure("hibernate.cfg.xml");
		Session session = null;
		Transaction transaction=null;
		try {
			
			session = conf.buildSessionFactory().openSession();
			transaction= session.beginTransaction(); 
			EmployeeEntity emp=new EmployeeEntity();
			//emp.setEmpid("10");
			String id=emp.getEmpid();
			//emp.setEmpfname("joal");
			//emp.setEmplname("kumar");
			//emp.setEmpdob(null);
			List<QualificationEntity> qualList=new ArrayList<>();
		
			qualList.add(new QualificationEntity("q001",""));
			
			emp.setQual(qualList);
			
			session.persist(emp);
			transaction.commit();
			session.close();
			
			System.out.println("Program ends");
	
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}	
		
	}

}
