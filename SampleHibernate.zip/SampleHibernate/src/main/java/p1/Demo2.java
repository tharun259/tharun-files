package p1;
 
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
 
public class Demo2 {
    public static void main(String[] args) {
        try {
            System.out.println("Program begins");
 
            Configuration cfg = new Configuration();
            cfg.configure("hibernate.cfg.xml");
            SessionFactory factory = cfg.buildSessionFactory();
 
            Session session1 = factory.openSession();
            Transaction tx1 = session1.beginTransaction();
 
            System.out.println("Fetching EmployeeEntity in Session 1...");
            EmployeeEntity ee1 = session1.get(EmployeeEntity.class, "1008");
            System.out.println("Session 1 result: " + ee1);
 
            tx1.commit();
            session1.close();
 
            Session session2 = factory.openSession();
            Transaction tx2 = session2.beginTransaction();
 
            System.out.println("Fetching EmployeeEntity in Session 2...");
            EmployeeEntity ee2 = session2.get(EmployeeEntity.class, "1008");
            System.out.println("Session 2 result: " + ee2);
 
            tx2.commit();
            session2.close();
            
            //factory.close();
            System.out.println("Program ends");
 
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
 