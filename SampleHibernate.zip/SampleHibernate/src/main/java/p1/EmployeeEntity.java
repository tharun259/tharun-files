package p1;

import java.util.Date;
import java.util.List;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Table(name="empmaster")
@Cacheable
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE)
@NamedQueries(
		{
			@NamedQuery(name="n1",query="from EmployeeEntity where empfname like :name"),
			@NamedQuery(name="n2",query="select distinct e from EmployeeEntity e " + "left join fetch e.qual")
		}
		)


public class EmployeeEntity {
	@Id
	private String empid;
	
	@Column
	private String empfname;
	private String emplname;
	private Date empdob;

	@ManyToMany
	//@JoinTable(name="empqualconnect")
	private List<QualificationEntity> qual;
	
	
	public EmployeeEntity(String empfname, String emplname, Date empdob) {
		super();
		this.empfname = empfname;
		this.emplname = emplname;
		this.empdob = empdob;
	}


	
	public List<QualificationEntity> getQual() {
		return qual;
	}



	public void setQual(List<QualificationEntity> qual) {
		this.qual = qual;
	}



	public EmployeeEntity(String empid, String empfname, String emplname, Date empdob, List<QualificationEntity> qual) {
		super();
		this.empid = empid;
		this.empfname = empfname;
		this.emplname = emplname;
		this.empdob = empdob;
		this.qual = qual;
	}



	public EmployeeEntity() {
		
	}

	public String getEmpid() {
		return empid;
	}
	public void setEmpid(String empid) {
		this.empid = empid;
	}
	public String getEmpfname() {
		return empfname;
	}
	public void setEmpfname(String empfname) {
		this.empfname = empfname;
	}
	public String getEmplname() {
		return emplname;
	}
	public void setEmplname(String emplname) {
		this.emplname = emplname;
	}
	public Date getEmpdob() {
		return empdob;
	}
	public void setEmpdob(Date empdob) {
		this.empdob = empdob;
	}
	@Override
	public String toString() {
		return " empid=" + empid + ", empfname=" + empfname + ", emplname=" + emplname + ", empdob="
				+ empdob;
	}
	
	
	
	
	
}
