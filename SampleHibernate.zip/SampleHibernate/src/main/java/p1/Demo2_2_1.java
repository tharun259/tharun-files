package p1;


import java.text.SimpleDateFormat;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class Demo2_2_1 {
	public static void main(String[] args) {
		
		Configuration confg=new Configuration();
		confg.configure("hibernate.cfg.xml");
		
		SessionFactory factory =confg.buildSessionFactory();
		SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd");
		Session session=null;
		Transaction tnx=null;
		
		try {
			 session=factory.openSession();
			 tnx=session.beginTransaction();
			 System.out.println("Enter emp id");
			// Query q1=session.createQuery("from SalaryEntity where empid=:n1");
			 
			 //q1.setParameter("n1", Read.sc.nextLine());
			 List<SalaryEntity> list=session.createQuery("from SalaryEntity",SalaryEntity.class).list();
			// List<SalaryEntity> list=q1.getResultList();
			 System.out.printf("%-10s %-15s %10s%n", "EmpId", "EFname", "Salary");
			 System.out.println("-".repeat(50));
			 
			 list.forEach(Demo2_2_1::f11);
			 tnx.commit();
			// f1(list.get(0));
			 session.close();
			 
			 
			 
		} catch (Exception e) {
			// TODO: handle exception

		    if (tnx != null) tnx.rollback();
		    e.printStackTrace();

		}
		
		
	}
	


public static void f11(SalaryEntity sal) {

System.out.printf("%-10s %-15s %10d%n",
    sal.getEmp().getEmpid(),        // String → %s
    sal.getEmp().getEmpfname(),     // String → %s
    sal.getSalary()                 // int → %d
);

}


	public static  void f1(SalaryEntity sal) {
		System.out.printf("%-10s %-15s %10d%n",sal.getEmp().getEmpid(), sal.getEmp().getEmpid(), sal.getSalary());
		//System.out.println(sal.getEmp().getEmpid()+"  "+sal.getEmp().getEmpid()+"  "+Date.format(sal.getDos())+"  "+sal.getSalary());
	}
	public static  void f2(SalaryEntity sal) {
		System.out.println(sal.getEmp().getEmpid()+"  "+sal.getEmp().getEmpfname()+"  "+sal.getSalary());

	}
}
