package p1;


import java.text.SimpleDateFormat;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import javax.persistence.Query;

public class Demo11_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Program begins");
		Configuration conf = new Configuration();
		conf.configure("hibernate.cfg.xml");
		Session session = null;
		Transaction transaction=null;
		SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd");
		try {
			
			session = conf.buildSessionFactory().openSession();
			transaction= session.beginTransaction(); 
			System.out.println("Enter the id need to be updated:");
			String empid=Read.sc.nextLine().trim();
			EmployeeEntity emp=new EmployeeEntity(Read.sc.nextLine(),Read.sc.nextLine(),date.parse(Read.sc.nextLine()));
			emp.setEmpid(empid);
			session.update(emp);
            transaction.commit();
			
		} catch (Exception e) {

            if (transaction != null) transaction.rollback();
            e.printStackTrace();

		}
		finally {

            session.close();
            System.out.println("Program ends");

		}
	}

}
