package p1;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Demo2_5_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Program begins");
		Configuration conf = new Configuration();
		conf.configure("hibernate.cfg.xml");
		Session session = null;
		Transaction transaction=null;
		try {
			
			session = conf.buildSessionFactory().openSession();
			transaction= session.beginTransaction(); 
			
			//String empId=Read.sc.nextLine();

		    EmployeeEntity emp = session.get(EmployeeEntity.class, "1010");
            
		    QualificationEntity qual= session.get(QualificationEntity.class, "q005");

		    emp.getQual().add(qual);
			session.persist(emp);
			transaction.commit();
			session.close();
			
			System.out.println("Program ends");
	
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}	
	}

}
