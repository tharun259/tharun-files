package p1;
 
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
 
@Entity
@Table(name ="empquality")
public class QualificationEntity {
	@Id
	private String qid;
	@Column
	private String qname;
	
	public QualificationEntity() {
	}
	public QualificationEntity(String qid, String qname) {
		super();
		this.qid = qid;
		this.qname = qname;
	}
 
	public String getQid() {
		return qid;
	}
	public void setQid(String qid) {
		this.qid = qid;
	}
	public String getQname() {
		return qname;
	}
	public void setQname(String qname) {
		this.qname = qname;
	}
	@Override
	public String toString() {
		return "QualificationEntity [qid=" + qid + ", qname=" + qname + "]";
	}
}