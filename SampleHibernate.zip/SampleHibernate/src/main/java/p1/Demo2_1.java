package p1;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;

public class Demo2_1 {
	public static void main(String[] args) {
		try {
			System.out.println("Program Starts");
			Configuration confg=new Configuration();
			confg.configure("hibernate.cfg.xml");
			SessionFactory factory =confg.buildSessionFactory();
			Session session =factory.openSession();
			Transaction trans=session.beginTransaction();
			SimpleDateFormat date=new SimpleDateFormat("yyyy-mm-dd");
			EmployeeEntity emp=new EmployeeEntity();
//			emp.setEmpid("5001");
//			
//			SalaryEntity smp=new SalaryEntity("T003",date.parse("1856-05-06"),45000,emp);
//			session.persist(smp);
			SalaryEntity smp;
			String ch="0";
			do {
				System.out.println("Enter the emp id ");
				emp.setEmpid(Read.sc.nextLine());
				System.out.println("Enter the trans id , date salary ");
				smp=new SalaryEntity(Read.sc.nextLine(),date.parse(Read.sc.nextLine()),Integer.parseInt(Read.sc.nextLine()),emp);
				session.persist(smp);
				System.out.println("Enter 1 to continoue");
				ch=Read.sc.nextLine();
				
			}while(ch.equals("1"));
			
			
			trans.commit();
			System.out.println("Program Ends");
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
	}
}
