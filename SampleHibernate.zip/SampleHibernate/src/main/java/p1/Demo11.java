package p1;

import java.sql.Date;
import java.text.SimpleDateFormat;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import javax.persistence.Query;

public class Demo11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Program begins");
		Configuration conf = new Configuration();
		conf.configure("hibernate.cfg.xml");
		Session session = conf.buildSessionFactory().openSession();
		Transaction transaction= session.beginTransaction(); ;
		try {
			
			SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd");
			System.out.println("Enter id");
			String s1 = Read.sc.nextLine();
			String fn = Read.sc.nextLine();
			String ln = Read.sc.nextLine();
			String dob = Read.sc.nextLine();
//            int rows = session.createNativeQuery(
//                    "DELETE FROM empmaster WHERE empid = :n1")
//                .setParameter("n1", s1) // or .setParameter("n1", id)
//                .executeUpdate();
//
//            if (rows == 0) {
//                System.out.println("No employee found for id: " + s1);
//            } else {
//                System.out.println("Successfully deleted " + rows + " record(s) for id: " + s1);
//            }
			Query q1=session.createQuery("UPDATE EmployeeEntity e SET e.empfname = :fn, e.emplname = :ln,e.empdob = :dob WHERE e.empid = :id");
			q1.setParameter("id", s1);
			q1.setParameter("fn", fn);
			q1.setParameter("ln", ln);
			Date da=Date.valueOf(dob);
			q1.setParameter("dob", da);
			int rows = q1.executeUpdate();
	          if (rows == 0) {
	        	  System.out.println("No employee found for id: " + s1);
		      } else {
		          System.out.println("Successfully updated " + rows + " record(s) for id: " + s1);
		      }
            transaction.commit();
			
		} catch (Exception e) {

            if (transaction != null) transaction.rollback();
            e.printStackTrace();

		}
		finally {

            session.close();
            System.out.println("Program ends");

		}
	}

}
