package p2;



import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import p1.UserDTO;



@Repository
public class ApplicationDAO {
	
	Session session =null;
	
	public ApplicationDAO(){
		Configuration conf=new Configuration();
		conf.configure("hibernate.cfg.xml");
		session=conf.buildSessionFactory().openSession();
	}
	
	public void storeRegister(UserDTO dto) {	
		Transaction tr=session.beginTransaction();
		System.out.println("username"+dto.getUsername());
		session.persist(dto);
		tr.commit();
	}
	public List<Map<String,Object>> checkUser(UserDTO ob) throws Exception{
		
		Transaction tx= session.beginTransaction();
		Query x=session.createNamedQuery("UserDTO.checkUser");
		x.setParameter("n1",ob.getUsername());
		x.setParameter("n2", ob.getPassword());
		List<Map<String,Object>> l1 =x.getResultList();
		tx.commit();	
		return l1;				
	}
	

}
