package p1;
 
import java.util.List;
import java.util.Map;
 
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
 
public class UserDAO {
	public void registerUser(UserDTO ob) throws Exception {
		Session session=HibernateSession.getSession();
		Transaction tx=session.beginTransaction();
		session.persist(ob);
		tx.commit();
	}
	
	public void createAcc(AccountHeadEntity ob) throws Exception {
		Session session=HibernateSession.getSession();
		Transaction tx=session.beginTransaction();
		session.persist(ob);
		tx.commit();

	}
	public UserDTO checkUser(UserDTO ob) throws Exception {
	    Session session = HibernateSession.getSession();
	    Transaction tx = session.beginTransaction();
	    try {
	        Query<UserDTO> q = session.createNamedQuery("UserDTO.checkUser", UserDTO.class);
	        q.setParameter("n1", ob.getUsername());
	        q.setParameter("n2", ob.getPassword());
	        UserDTO result = null;
	        try {
	            result = q.getSingleResult();
	        } catch (javax.persistence.NoResultException e) {
	            result = null;
	        }
	        tx.commit();
	        return result;
	    } catch (Exception e) {
	        tx.rollback();
	        throw e;
	    }
	}

}