package p1;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
 
@Controller
@RequestMapping()
public class AppController {
    UserDAO dao = new UserDAO();
    @GetMapping("/register1")
    public String f0() {
        return "register"; // returns register.jsp
    }
    @PostMapping("/register")
    public String register(@RequestParam String username,
                           @RequestParam String password,
                           @RequestParam String pan,
                           @RequestParam String aadhar,
                           @RequestParam String email,
                           ModelMap mp) {
        UserDTO dto = new UserDTO();
        dto.setUsername(username);
        dto.setPassword(password);
        dto.setPan(pan);
        dto.setAadhar(aadhar);
        dto.setEmail(email);
        try {
            dao.registerUser(dto);
            return "success"; 
        } catch (Exception e) {
            mp.put("msg", e.getMessage());
            return "login";
        }
    }
 // AppController.logout()
    @GetMapping("/logout")
    public String fl(HttpSession session) throws Exception {
        session.invalidate();
        Session s = HibernateSession.getSession();
        if (s != null && s.isOpen()) {
            s.close();
        }
        HibernateSession.reset(); // add this method (below)
        return "login";
    }
    @GetMapping("/login1")
    public String f1() {
        return "login"; 
    }
    @PostMapping("/login")
    public String login(@RequestParam String username,
                        @RequestParam String password,
                        ModelMap mp ,HttpSession session) {
        UserDTO dto = new UserDTO();
        dto.setUsername(username);
        dto.setPassword(password);
        try {
            UserDTO l1 = dao.checkUser(dto);
            if (l1 == null) {
                throw new Exception("Invalid User");
            }
           session.setAttribute("username", username);
           User.name = (username.trim()).replaceAll(" ", "");
            return "home"; 
        } catch (Exception e) {
            mp.put("msg", e.getMessage());
            return "login";
        }
    }
    @GetMapping("/newaccount")
   public String f5()
   {
    	return "newaccount";
   }
   @PostMapping("/accounthead")
   
   public String newaccounthead(@RequestParam String aname,
                       @RequestParam String description,
                       @RequestParam String atype,
                       @RequestParam String balance,
                       ModelMap mp ,HttpSession session) {
       AccountHeadEntity dto = new AccountHeadEntity();
       dto.setAccname(aname);
       UserDAO dao=new UserDAO();
       dto.setDescription(description);
       dto.setAtype(atype);
       dto.setInitialbalance(Long.parseLong(balance));
       dto.setCurrentbalance(Long.parseLong(balance));
       dto.setUsername(User.name);
       try {
           dao.createAcc(dto);
   
           mp.put("msg","Account added");
           return "home"; 
       } catch (Exception e) {
           mp.put("msg", e.getMessage());
           return "home";
       }
   }
}