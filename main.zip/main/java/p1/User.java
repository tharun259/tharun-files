package p1;

public class User {
	public static String name="";
public static void main(String[] args) {
	
	 
}
}
