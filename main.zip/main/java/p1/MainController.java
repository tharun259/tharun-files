
package p1;
import p2.ApplicationDAO;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;


 
@Controller
@RequestMapping("/app")
public class MainController {
	
	String s1="bejoy";
	@GetMapping("welcome")
	public String f1(ModelMap map) {
		map.put("msg",s1);
		
		return "welcome";
	}
	
	ApplicationDAO dao=new ApplicationDAO();
	
	@GetMapping("/register1")
	public String f0() {
		return "register";
	}
	
	@PostMapping("/register")
	public String register(@RequestParam String username,@RequestParam String password,ModelMap mp) {
		UserDTO dto=new UserDTO();
		dto.setUsername(username);
		dto.setPassword(password);
		
		try {
			dao.storeRegister(dto);
			return "success";
		} catch (Exception e) {
			mp.put("msg", e.getMessage());
			return "welcome";
			// TODO: handle exception
		}
	}
	
	@GetMapping("/login1")
	public String f1() {
		return "login";
	}
	@PostMapping("/login")
	public String login(@RequestParam String username,@RequestParam String password,ModelMap mp)  {
		UserDTO dto=new UserDTO();
		dto.setUsername(username);
		dto.setPassword(password);
		
		try {
			List<Map<String, Object>> l1=dao.checkUser(dto);
			if(l1.isEmpty()) {
				throw new Exception("Invalid User");
			}
			//session.setAttribute("loggedInUsername", username);
			return "home";
		} catch (Exception e) {
			mp.put("msg", e.getMessage());
			return "welcome";
			// TODO: handle exception
		}
		
	}
	
//	@GetMapping("home")
//	public String f9(ModelMap mp,HttpSession session) {
//		String username = (String) session.getAttribute("loggedInUsername");
//		
//		
//
//        if (username == null) {
//            // Not logged in; redirect to login page
//            return "redirect:/app/login1";
//        }
//        mp.put("username",username);
//        return "home";
//	}
	
	
//	
//	@PostMapping("register")
//	public String f4(@RequestParam String userid, @RequestParam String username,ModelMap mp) {
//		UserDTO ud=new UserDTO();
//		ud.setUserid(userid);
//		ud.setUsername(username);
//		mp.put("user", ud);
//		
//		return "login";
//	}

}
 