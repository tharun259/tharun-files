package p1;
 
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
 
//HibernateSession.java
public class HibernateSession {
 private static Session session = null;
 public static Session getSession() throws Exception {
     if (session == null || !session.isOpen()) {
         Configuration config = new Configuration();
         config.configure("hibernate.cfg.xml");
         session = config.buildSessionFactory().openSession();
     }
     return session;
 }
 public static void reset() {
     session = null;
 }
}