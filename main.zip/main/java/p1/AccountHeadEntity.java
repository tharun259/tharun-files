package p1;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="ahead")
public class AccountHeadEntity {
	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid",strategy = "uuid2")
	private String accno;
	
	@Column
	private String accname;
	private String username;
	private String description;
	private String atype;
	private long initialbalance; 
	private long currentbalance;
	public String getAccno() {
		return accno;
	}
	public void setAccno(String accno) {
		this.accno = accno;
	}
	public String getAccname() {
		return accname;
	}
	public void setAccname(String accname) {
		this.accname = accname;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getAtype() {
		return atype;
	}
	public void setAtype(String atype) {
		this.atype = atype;
	}
	public long getInitialbalance() {
		return initialbalance;
	}
	public void setInitialbalance(long initialbalance) {
		this.initialbalance = initialbalance;
	}
	public long getCurrentbalance() {
		return currentbalance;
	}
	public void setCurrentbalance(long currentbalance) {
		this.currentbalance = currentbalance;
	}
}