package com.example.h2demo;


import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
 
 
 
@Repository
public interface StudentDAO extends JpaRepository<StudentEntity, Integer>{
	
	List<StudentEntity> findByFirstnameIgnoreCase(String firstname);
	StudentEntity findByFirstnameAndLastname(String firstname, String lastname);
	
//	@Query(name="StudentEntity.findbypattern" , nativeQuery = false)
//	public List<StudentEntity> findPattern(String n1){
//		return
//	}
	
	@Query(value ="select upper(firstname) , lower(lastname) from students",nativeQuery = true)
	public List<String> getallname();
}




 