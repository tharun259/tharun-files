DROP TABLE IF EXISTS students;

CREATE TABLE students (
    studentid INT PRIMARY KEY,
    firstname VARCHAR(100) NOT NULL,
    lastname VARCHAR(100) NOT NULL,
    dob DATE NOT NULL
);

INSERT INTO students (studentid, firstname, lastname, dob)
VALUES
  (1, 'John',  'Doe',        '2002-05-14'),
  (2, 'Emma',  'Watson',     '2003-11-22'),
  (3, 'Arjun', 'Reddy',      '2001-09-03'),
  (4, 'Sara',  'Khan',       '2004-02-17'),
  (5, 'David', 'Miller',     '2000-12-01');