package com.example.h2demo;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;

class StudentEntityTest {

    @Test
    @DisplayName("Getters and Setters should work correctly")
    void testGettersAndSetters() {
        StudentEntity s = new StudentEntity();

        int id = 101;
        String first = "John";
        String last = "Doe";
        Date dob = new Date(946684800000L); // 2000-01-01 UTC

        s.setStudentid(id);
        s.setFirstname(first);
        s.setLastname(last);
        s.setDob(dob);

        assertEquals(id, s.getStudentid());
        assertEquals(first, s.getFirstname());
        assertEquals(last, s.getLastname());
        assertEquals(dob, s.getDob());
    }

    @Test
    @DisplayName("@Entity annotation should be present on StudentEntity")
    void testEntityAnnotationPresent() {
        assertTrue(StudentEntity.class.isAnnotationPresent(Entity.class),
                "@Entity should be present on StudentEntity");
    }

    @Test
    @DisplayName("@Table(name = \"students\") should be present")
    void testTableAnnotationAndName() {
        Annotation tableAnn = StudentEntity.class.getAnnotation(Table.class);
        assertNotNull(tableAnn, "@Table should be present on StudentEntity");

        Table table = (Table) tableAnn;
        assertEquals("students", table.name(), "Table name should be 'students'");
    }

    @Test
    @DisplayName("@Id should be present on field 'studentid'")
    void testIdAnnotationOnStudentId() throws NoSuchFieldException {
        Field idField = StudentEntity.class.getDeclaredField("studentid");
        assertNotNull(idField, "Field 'studentid' should exist");
        assertTrue(idField.isAnnotationPresent(Id.class), "@Id should be present on 'studentid'");
    }

    @Test
    @DisplayName("Default values should be null/zero before setting")
    void testDefaultValues() {
        StudentEntity s = new StudentEntity();
        assertEquals(0, s.getStudentid(), "Default int should be 0");
        assertNull(s.getFirstname(), "Default firstname should be null");
        assertNull(s.getLastname(), "Default lastname should be null");
        assertNull(s.getDob(), "Default dob should be null");
    }
}
