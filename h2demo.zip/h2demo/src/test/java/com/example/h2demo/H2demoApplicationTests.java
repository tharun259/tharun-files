package com.example.h2demo;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Sql("/data.sql") 
class H2demoApplicationTests {

    @Autowired
    private MockMvc mockMvc;
    
    @Autowired
    private MController ob;
    

    @Test
    void contextLoads() {
        // If the application context fails to start, this test will fail.
    }
    

    @Test
    void main_runs_without_exceptions() {
        assertDoesNotThrow(() -> H2demoApplication.main(new String[]{}));
    }

    
    @Test
    public void testcase1() {
    	ResponseEntity<String> x = ob.f1();
    	assertEquals("Welcme To Spring Rest Services", x.getBody());
    }
    @Test
    public void testcase2() {
    	List<StudentEntity> x = ob.f2();
    	assertFalse(x.size()==0);
    }

    @Test
    public void testcase3() {
    	List<StudentEntity> x = ob.f2();
    	assertEquals(x.size(),5);
    }
    @Test
    void getById_returns404_andEmptyBody_whenStudentDoesNotExist() throws Exception {
        
        MvcResult result = mockMvc.perform(get("/students/99"))
                                  .andReturn();

        assertEquals(404, result.getResponse().getStatus());
        
    }
}