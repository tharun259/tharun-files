package com.example.p1;



import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.firstRestService.StudentDAO;
import com.example.firstRestService.StudentEntity;

@org.springframework.web.bind.annotation.RestController
@RequestMapping("c1")   // Base path
public class RestController {
	
	@Autowired
	StudentDAO dao;
	
	
    @GetMapping("/m")   // Endpoint
    public ResponseEntity<String> f1() {
        return new ResponseEntity<String>("welcome to spring",HttpStatus.OK);
    }
    
    @GetMapping("/students")
    public List<StudentEntity> f33(){
    	return dao.findAll();
    }
    
    @GetMapping("/students/{id}")
	public ResponseEntity<StudentEntity> getById(@PathVariable int id) {
	    return dao.findById(id)
	              .map(ResponseEntity::ok)
	              .orElseGet(() -> ResponseEntity.notFound().build());
	}

    
    @GetMapping("/student/{fname}")
    public ResponseEntity<List<StudentEntity>> searchByFirstname(
            @PathVariable String fname) {
        List<StudentEntity> results = dao.findByFirstnameIgnoreCase(fname);
        return ResponseEntity.ok(results);
    }
    
    @GetMapping("/student1/{fname}/{lname}")
	public ResponseEntity<StudentEntity> f4(@PathVariable String fname,@PathVariable String lname){
		try {
			StudentEntity ob = dao.findByFirstnameAndLastname(fname,lname);
			if(ob == null)
			{
				throw new Exception("Id not found");
			}
			return new ResponseEntity<StudentEntity>(ob,HttpStatus.OK);
		}
		catch(Exception e) {
			return ResponseEntity.notFound().build();
		}		
	}
    @PostMapping("/addstudent")
    public ResponseEntity<String> addStudents(@RequestBody StudentEntity ob) {
    	try {
    		dao.save(ob);
    		return new ResponseEntity<String>("student added ",HttpStatus.OK);
		} catch (Exception e) {
			// TODO: handle exception
			return new ResponseEntity<String>("non added ",HttpStatus.BAD_REQUEST);
		}
    }
    @PostMapping("/updatestudent")
    public ResponseEntity<String> updateStudents(@RequestBody StudentEntity ob) {
    	try {	
    		 if (dao.existsById(ob.getStudentid())) {
    			 dao.save(ob);
    			 return new ResponseEntity<String>("student updated ",HttpStatus.OK);
    		 }else {
    			 return new ResponseEntity<String>("student id not found ",HttpStatus.NOT_FOUND);
    		 }
    		 }
		 catch (Exception e) {
			// TODO: handle exception
			return new ResponseEntity<String>("not updated ",HttpStatus.BAD_REQUEST);
		}
    }
    
    @GetMapping("/delete/{id}")
	public ResponseEntity<String> deletById(@PathVariable int id) {

        if (!dao.existsById(id)) {
        	return new ResponseEntity<String>("Id not found",HttpStatus.NOT_FOUND);
        }
        dao.deleteById(id);
        return new ResponseEntity<String>("Deleted successully",HttpStatus.OK);
	}
    
    @GetMapping("/getallname")
    public List<String> f10() {
    	return dao.getallname();
    }
    
    
}