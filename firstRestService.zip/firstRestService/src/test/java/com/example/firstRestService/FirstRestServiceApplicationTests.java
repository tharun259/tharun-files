package com.example.firstRestService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstRestServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
