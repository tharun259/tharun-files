package com.example.eurekaclient;


import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/employees")
public class EmployeeController {
	@Autowired
	private EmployeeService empservice;
	
	@GetMapping("/{id}")
	private ResponseEntity<EmployeeObject> getEmployeeDetails(@PathVariable("id") int id){
		EmployeeObject emp=empservice.getEmployeeById(id);
		return  ResponseEntity.status(HttpStatus.OK).body(emp);
	}
	@GetMapping

public List<EmployeeObject> getAllEmployees() {
        return empservice.getEmployees();
    }
	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public EmployeeObject add(@RequestBody Map<String, Object> body) {
	    Employee emp = new Employee();
	 
	    emp.setName((String) body.get("name"));
	    emp.setAge((Integer) body.get("age"));
	    Employee saved=empservice.addEmployee(emp);// save() provided by CrudRepository [1](https://seoinfotech.com/spring-boot-service-discovery-eureka/)

	    EmployeeObject out = new EmployeeObject();
	    out.setId(saved.getId());
	    out.setName(saved.getName());
	    out.setAge(saved.getAge());
	    return out;
	}
	@DeleteMapping("/{id}")
	@ResponseStatus(HttpStatus.ACCEPTED)
	public void deleteEmployee(@PathVariable("id") int id  ) {
	empservice.removeEmployee(id);
	}
	

}
