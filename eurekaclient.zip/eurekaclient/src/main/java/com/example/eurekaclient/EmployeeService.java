package com.example.eurekaclient;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeService {
@Autowired
private EmployeeRepository emprepo;
public EmployeeObject getEmployeeById(int id) {

    Employee employee = emprepo.findById(id)
            .orElseThrow(() -> new RuntimeException("Employee not found: " + id));
    EmployeeObject e=new EmployeeObject();
    e.setId(employee.getId());
    e.setName(employee.getName());
    e.setAge(employee.getAge());
    return e;

}
public List<EmployeeObject> getEmployees(){
	Iterable<Employee> emps=emprepo.findAll();
	List<EmployeeObject> empList=new ArrayList<>();
	for(Employee employee:emps) {
		EmployeeObject e=new EmployeeObject();
	    e.setId(employee.getId());
	    e.setName(employee.getName());
	    e.setAge(employee.getAge());
	    empList.add(e);
	}
	return empList;
}
public Employee addEmployee(Employee emp) {
	Employee saved = emprepo.save(emp); 
	return saved;
}
public void removeEmployee(int id) {
	emprepo.deleteById(id);
}
}
