package com.example.firstRestService;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
 

 
@Repository
public interface StudentDAO extends JpaRepository<StudentEntity, Integer>{
	
	List<StudentEntity> findByFirstnameIgnoreCase(String firstname);
	StudentEntity findByFirstnameAndLastname(String firstname, String lastname);
	

	@Query(value ="select upper(firstname) , lower(lastname) from students",nativeQuery = true)
	public List<String> getallname();
}
