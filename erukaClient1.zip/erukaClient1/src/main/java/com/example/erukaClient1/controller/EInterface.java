package com.example.erukaClient1.controller;



import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient("http://firstRestService/c1")
public interface EInterface {
	@GetMapping("/m")
	public ResponseEntity<String> f1();
	
	@GetMapping("/students")
	public List<StudentEntity> f3();
}
