package com.example.erukaClient1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@EnableFeignClients
@Configuration
public class ErukaClient1Application {
	
	@Bean
	public RestTemplate f1() {
		return new RestTemplate();
	}

	public static void main(String[] args) {
		SpringApplication.run(ErukaClient1Application.class, args);
	}

}
