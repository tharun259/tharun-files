package com.example.erukaClient1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("a1")
public class EController {
	
	@Autowired
	private RestTemplate rt;
	
	@Autowired
	private EInterface ob;
	
	@GetMapping("/e1")
	public String f11(){
		String url="http://localhost:9090/c1/m";
				return rt.getForObject(url, String.class);
	}
	
	@GetMapping("/e2")
	public ResponseEntity<String> s2(){
		return ob.f1(); 
	}
	
	@GetMapping("/e3")
	public List<StudentEntity> s3(){
		return ob.f3();
	}
}
