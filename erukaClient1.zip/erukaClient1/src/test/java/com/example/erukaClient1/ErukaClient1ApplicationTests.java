package com.example.erukaClient1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ErukaClient1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
