package com.example.studentMarks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentMarksApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentMarksApplication.class, args);
	}

}
