package com.example.eurekaclient1;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient("http://eurekaclient")
public interface ClientInterface {
@GetMapping("/employees")
public ResponseEntity<String> showemployees();



}
